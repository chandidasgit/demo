# Torvalds Ipsum

A Lorem Ipsum with Linus Torvalds quotes

The intention of this project is to have an alternative to basic Lorem Ipsum using some of Linus Torvals quotes.

## Contributing 

You can help the project adding more linus quotes. Just FORK the repository, add more quotes and open a Pull Request.

## See this in action

Access: [www.torvaldsipsum.com](http://www.torvaldsipsum.com) to see the project in action.


## License

[The MIT License (MIT) Copyright (c) 2013](http://opensource.org/licenses/MIT) 